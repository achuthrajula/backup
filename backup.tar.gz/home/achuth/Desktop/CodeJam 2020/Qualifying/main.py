import numpy as np

t = int(input())
arr = []

def solve():
  n,k = map(int,input().split())
  sample_list = list(np.arange(1,n+1))
  arr = list()
  arr2 = sample_list
  for x in range(n):
    subArr = arr2
    arr.append(list(subArr))
    ele = subArr.pop()
    subArr.insert(0,ele)
    arr2 = subArr
  arr = np.array(arr)
  flipped_arr = np.fliplr(arr)
  if arr.trace() == k or flipped_arr.trace() == k:
    return "POSSIBLE"
  else:
    return "IMPOSSIBLE"

for x in range(1,t+1):
  print("Case #{}: {}".format(x,solve()))