t = int(input())
out = list()
position = 0

def opening(index,n):
  global position, out
  for _ in range(n): 
    out.insert(index,'(')
  position = len(out)

def closing(index,n):
  global position, out
  for _ in range(n): 
    out.insert(index,')')
  position = len(out)

def solve():
  global position
  global out
  out = []
  n = input()
  opening(0,int(n[0]))
  out.insert(int(n[0]),n[0])
  position += 1
  for x in range(1,len(n)):
    out.insert(position,n[x])
    position += 1
    val = int(n[x-1])-int(n[x])
    if val > 0: 
      closing(position-1,val)
    elif val < 0:
      opening(position-1,abs(val))
    else: pass
  closing(len(out)+1,int(n[len(n)-1]))
  s_out = ''
  print(out)
  for i in range(len(out)):
    s_out += out[i]
  return s_out

for x in range(1, t + 1):
  print("Case #{}: {}".format(x,solve()))