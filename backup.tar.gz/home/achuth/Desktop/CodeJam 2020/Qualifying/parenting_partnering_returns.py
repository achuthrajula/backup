t = int(input())

def solve():
  n = int(input())
  jobs = {}
  for x in range(n):
    start, end = [int(x) for x in input().split()]
    jobs[x] = {"start": start, "end": end}
  jamie = {'isFree': True, 'currentDeadline': 0}
  cameron = {'isFree': True, 'currentDeadline': 0}
  sorted_jobs = sorted(jobs.items(), key=lambda x: x[1]['start'])
  assigned_jobs = dict()
  legit = True
  for event in sorted_jobs:
    if cameron['isFree']:
      cameron['isFree'] = False
      cameron['currentDeadline'] = event[1]['end']
      assigned_jobs[event[0]] = 'C'
    elif event[1]['start'] >= cameron['currentDeadline']:
      cameron['isFree'] = False
      cameron['currentDeadline'] = event[1]['end']
      assigned_jobs[event[0]] = 'C'
    elif jamie['isFree']:
      jamie['isFree'] = False
      jamie['currentDeadline'] = event[1]['end']
      assigned_jobs[event[0]] = 'J'
    else:
      if event[1]['start'] >= jamie['currentDeadline']:
        jamie['isFree'] = False
        jamie['currentDeadline'] = event[1]['end']
        assigned_jobs[event[0]] = 'J'
      else:
        legit = False
  if legit:
    sol = ''
    for event in sorted(assigned_jobs.keys()):
      sol += assigned_jobs[event]
    return sol
  else:
    return 'IMPOSSIBLE'

for x in range(1,t+1):
  print("Case #{}: {}".format(x,solve()))