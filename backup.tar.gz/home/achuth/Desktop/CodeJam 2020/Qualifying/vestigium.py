import numpy as np

t = int(input())


def solve(t):
    rep_row = 0
    rep_col = 0
    n = int(input())
    l = list()
    for x in range(n):
        l.append(list(map(int, input().split())))
    matrix = np.array(l)
    matrix_1 = matrix.T
    for i in range(n):
        s = set(matrix[i])
        s1 = set(matrix_1[i])
        if len(s) != n:
            rep_col += 1
        if len(s1) != n:
            rep_row += 1

    print("Case #{}: {} {} {}".format(t, matrix.trace(), rep_col, rep_row))


for x in range(1, t + 1):
    solve(x)
