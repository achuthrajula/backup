t = int(input())
while t != 0:
  safe = True
  n = int(input())
  l = list(map(int,input().split()))
  for i in range(len(l)):
    if l[i] == 1:
      count = 0
      i += 1
      # print('s',len(l[i:len(l)]))
      while i < len(l):
        if l[i] == 0: count += 1
        elif l[i] == 1:
          if count >= 5:
            break
          else:
            print("NO")
            safe = False
            break
        i += 1
    if safe == False: break  
  if safe == True: print("YES")
  t -= 1