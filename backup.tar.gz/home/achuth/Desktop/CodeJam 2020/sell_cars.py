t = int(input())
while t != 0:
    n = int(input())
    l = sorted(list(map(int,input().split())),reverse=True)
    sum = 0
    for i in range(n):
        sub = l[i]-i
        if sub >= 0:
            sum += sub
    print(sum%1000000007)
    t -= 1
