  // Set the configuration for your app
  // TODO: Replace with your project's config object
let firebase = require('firebase');

var config = {
  apiKey: "apiKey",
  authDomain: "projectId.firebaseapp.com",
  databaseURL: "https://test-303c6.firebaseio.com",
  storageBucket: "bucket.appspot.com"
};
firebase.initializeApp(config);

  // Get a reference to the database service
var database = firebase.database();


//write data
function writeUserData(userId, name, email, mobile) {
  database.ref('users/' + userId).set({
    username: name,
    email: email,
    mobile : mobile
  })
  .then(() => console.log('success'))
  .catch((error) => console.log(error));
}

//read data
database.ref('/users/' + 9162).once('value').then(function(snapshot) {
  // var username = (snapshot.val() && snapshot.val().username) || 'Anonymous';
  console.log(snapshot.val())
});

//delete data
// let userRef = database.ref('users/' + 9161);
// userRef.remove()
// .then(() => console.log('deleted successfully'))
// .catch((error) => console.log(error))


writeUserData(9161, 'Achuth', 'achuthrajula1999@gmail.com', 7981936393)

//update data
let userRef = database.ref('/users')
userRef.child(9161).update({'username': 'rajula'})
.then(() => console.log('successfully modified'))
.catch((error) => console.log(error))
