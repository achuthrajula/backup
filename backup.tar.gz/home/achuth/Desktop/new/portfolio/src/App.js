import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import Clock from './clock';
import Navb from './navbar';
import Image from './me.jpg'
import { Jumbotron, Container, Row, Col } from 'reactstrap';
import './css/App.css';
import Footer from './footer';

function App() {
  return (
    <div className="App">
            <Navb />
      <Container className="head">
        <Clock />
    </Container>
      <header className="App-header">
        <Container>
          <Row className="content">
            <Col>
            <Jumbotron className="jumbotron">
              <Container>
                <Row>
                  <Col xs="8">
                    <h1 className="display-5">About Me</h1>
                    <hr className="my-2"/>
                    <p className="lead">I'm Achuth Rajula a computer science enthusiast and a CS Undergraduate, who specializes in Artificial Intelligence and Web Technologies from <a href="http://www.klh.edu.in/">KLEF Hyderabad</a></p>
                    <hr className="my-2" />
                  </Col>
                  <Col xs="4">
                     <img src={Image} thumbnail className="thumbnail img-responsive" alt="thumbnail"/>
                  </Col>
                </Row>
              </Container>
      </Jumbotron>
            </Col>
          </Row>
          <Row className="Content">
            <Col>
            <Jumbotron className="jumbotron">
              <Container>
                <Row>
                  <Col xs="8">
                    <h1 className="display-5">My Skills</h1>
                    <hr className="my-2"/>
                      
                    <hr className="my-2" />
                  </Col>
                  <Col xs="4">
                    Most of the skills I possess are self taught and  purely learnt out of passion and enthusiasm. 
                  </Col>
                </Row>
              </Container>
      </Jumbotron>
            </Col>
          </Row>
          
        </Container>
      </header>
      <Footer />
    </div>
  );
}

export default App;
