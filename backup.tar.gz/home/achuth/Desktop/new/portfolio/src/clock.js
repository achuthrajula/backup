import React from 'react';
import Title from './title';
import { Row, Col } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.css';
import './css/clock.css';

class Clock extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        date: new Date(),
      };
    }
  
    componentDidMount() {
      this.timerID = setInterval(
        () => this.tick(),
        1000
      );
    }
  
    componentWillUnmount() {
      clearInterval(this.timerID);
    }
  
    tick() {
      this.setState({
        date: new Date()
      });
    }
  
    render() {
      return (
        <div> 
          <Row>
          <Col xs="10">
            <Title hour={ this.state.date.getHours() } />
        </Col>
          <Col xs="2">
    <h5 className="clock">{this.state.date.toDateString()}</h5>
          <h5 className="clock">{this.state.date.toLocaleTimeString()}.</h5>
          </Col>
          </Row>
        </div>
      );
    }
  } 

export default Clock;
