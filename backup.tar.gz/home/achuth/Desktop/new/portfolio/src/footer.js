import React from 'react';
import './css/footer.css';
import { SocialIcon } from 'react-social-icons';

function footer() {
    return (
      <div className="footer">
        <SocialIcon className="app" url="https://github.com/achuthrajula" bgColor="#282c34" fgColor="white"/>
        <SocialIcon className="app" url="https://www.linkedin.com/in/achuth-rajula-162048177/" bgColor="#282c34" fgColor="white"/>    
        <SocialIcon className="app" url="https://www.instagram.com/achuthrajula._/?hl=en" bgColor="#282c34" fgColor="white"/>       
        <SocialIcon className="app" url="https://www.facebook.com/achuth09" bgColor="#282c34" fgColor="white"/> 
      </div>
    );
}

export default footer;
