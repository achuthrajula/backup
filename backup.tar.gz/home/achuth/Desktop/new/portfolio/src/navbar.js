import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import './css/navbar.css';
import Resume from './resume';

import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  NavbarText
} from 'reactstrap';

const Navb = (props) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggle = () => setIsOpen(!isOpen);

  return (
    <div>
      <Navbar className="nav" color="dark" dark expand="md">
        <NavbarBrand href="/">achuthrajula</NavbarBrand>
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
          <Nav className="mr-auto" navbar>
            <NavItem>
              <NavLink href="https://github.com/achuthrajula" target="_blank">GitHub</NavLink>
            </NavItem>
          </Nav>
          <NavbarText>
            <Resume />
            </NavbarText>
        </Collapse>
      </Navbar>
    </div>
  );
}

export default Navb;