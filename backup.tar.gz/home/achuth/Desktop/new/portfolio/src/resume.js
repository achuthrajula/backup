import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import './css/resume.css';
import Pdf from './resume.pdf';

function Title() {
  return (
    <div className="resume">
        <a href = {Pdf} rel="noopener noreferrer" target = "_blank">
              My Resume
              </a>
    </div>
  );
}

export default Title;
