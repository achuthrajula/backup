import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import './css/title.css';

const Title = (hour) => {
    let part = ''
    const greet = hour.hour
    if  (greet < 12) {
      part = 'Good Morning'
    }
    else if (greet >= 12 && greet < 17) {
      part = 'Good Afternoon'
    }
    else {
      part = 'Good Evening'
    }
    return (
      <div>
        <h5 className="greet">{part},</h5>
        <br /><br />
        <h5 className="n1">I'm</h5>
          <h2 className="name">Achuth Rajula.</h2>
          <h2 className="year">CS Undergraduate KLUH '21</h2>
      </div>
    );
  }

export default Title;
