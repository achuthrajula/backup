import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import './css/clock.css';

class Clock extends React.Component {
    constructor(props) {
      super(props);
      this.state = {date: new Date()};
    }
  
    componentDidMount() {
      this.timerID = setInterval(
        () => this.tick(),
        1000
      );
    }
  
    componentWillUnmount() {
      clearInterval(this.timerID);
    }
  
    tick() {
      this.setState({
        date: new Date()
      });
    }
  
    render() {
      return (
        <div> 
    <h5 className="clock">{this.state.date.toDateString()}</h5>
          <h5 className="clock">{this.state.date.toLocaleTimeString()}.</h5>
        </div>
      );
    }
  } 

export default Clock;
