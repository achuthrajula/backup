import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import { Jumbotron, Container, Row, Col } from 'reactstrap';
import { IoIosCode } from "react-icons/io";
import './css/skills.css';

function Skills() {
  return (
    <Jumbotron className="jumbotron">
              <Container>
                <Row>
                  <Col>
                  <h1 className="display-5">Skills</h1>
                  <hr className="my-2"/>
                    <Container>
                        <Row>
                            <Col xs="6" className="left">
                                <h6><IoIosCode /> Javascript</h6> 
                                <h6><IoIosCode /> Node.js</h6>
                                <h6><IoIosCode /> React.js</h6>
                                <h6><IoIosCode /> MongoDB</h6>  
                                <h6><IoIosCode /> Express.js</h6>
                                <h6><IoIosCode /> Bootstrap 4</h6>   
                            </Col>
                            <Col xs="6" className="right">
                                <h6><IoIosCode /> Python</h6>
                                <h6><IoIosCode /> C</h6> 
                                <h6><IoIosCode /> Git</h6>
                                <h6><IoIosCode /> Bash</h6>  
                                <h6><IoIosCode /> Java</h6>
                            </Col>
                        </Row>
                     </Container>    
                    <hr className="my-2" />
                  </Col>
                </Row>
              </Container>
      </Jumbotron>
  );
}

export default Skills;
