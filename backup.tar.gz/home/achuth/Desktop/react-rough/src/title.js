import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import './css/title.css';

class Title extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      hour: null
    }
  }

  componentDidMount() {
    this.getHour()
  }

  getHour = () => {
    const date = new Date()
    const hour = date.getHours()
    let part = ''

    if  (hour < 12) {
      part = 'Good Morning'
    }
    else if (hour > 12 && hour < 17) {
      part = 'Good Afternoon'
    }
    else {
      part = 'Good Evening'
    }

    this.setState({
       hour: part
    });
   }
 
  render() {
    const hour = this.state.hour;
    return (
      <div>
        <h5 className="greet">{hour},</h5>
        <br /><br />
        <h5 className="n1">I'm</h5>
          <h2 className="name">Achuth Rajula.</h2>
          <h2 className="year">CS Undergraduate KLUH '21</h2>
      </div>
    );
  } 
}

export default Title;
